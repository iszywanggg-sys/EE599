# EE599 离线实验流程样例

Python 3.9 或更新版本，无第三方依赖，无需联网、GPU、API 密钥。

## 开始运行

解压后，在本目录打开终端：

```bash
python pipeline.py
python -m unittest -v
```

Windows 如果 python 不可用，换成 `py`；macOS/Linux 可用 `python3`。

默认生成 12 条合成记录，含 6 个正确答案和 6 个错误答案，每条运行四种条件，共 48 次模拟检查。

```bash
python pipeline.py --selector random --budget 12 --output outputs/random
python pipeline.py --selector recency --budget 12 --output outputs/recency
python pipeline.py --selector relevance --budget 12 --output outputs/relevance
python pipeline.py --input outputs/demo/samples.jsonl --output outputs/replay
```

每次使用独立 output 目录；同一目录重跑会覆盖结果，不自动续跑。

## 结果文件

- samples.jsonl：固定的输入记录；包含评估标签，不能直接整条传给模型。
- results.jsonl：每次检查的实际请求、模拟返回值、错误、请求哈希和耗时。
- summary.csv：召回率、错误拒绝率、平衡准确率、成功/失败数和长度/耗时统计。
- manifest.json：随机种子、预算、样本哈希和 MOCK 标记。

真实标签只在评估端使用；build_request 使用字段白名单构造模型输入。分类器和筛选器也不接收正确性标签。

## 流程与接口

1. 输入题目、候选答案和有序 trajectory。
2. classify(trajectory)：目前 tool 角色归 E，assistant 角色归 R；保留块 ID、顺序与来源。替换成 Kai 的分类模块。
3. select_evidence(...)：选择 E 的子集并恢复原始顺序。jev_mock 与 relevance 当前都按词汇交集排序，只用于占位；并不是实际 Jev。
4. build_request(...)：生成 full、qa_only、no_reasoning、selected_evidence 四类请求。完整上下文保留 E/R 的交错顺序。
5. mock_verify(request)：替换为 Magnus 的真实模型调用。请求是一个 Python dict；返回至少包含 verdict（correct/incorrect）和 reason。
6. summarize(rows)：关联样本标签，统计每个条件的结果。失败调用单独报告，不当作判错；指标只统计成功且有标签的记录。正式实验应检查各条件共同成功的配对样本，并报告置信区间。

## 数据格式

输入为 JSONL，每行一个对象，查看附带 samples.jsonl 即可。字段：

- id：唯一字符串。
- question：问题文本。
- candidate_answer：solver 的候选答案。
- trajectory：按发生顺序记录的块列表；每块包含 id、role、text，可附 source 等元数据。
- label_correct：可选布尔值。表示候选答案实际是否正确；不是检查者的判断。省略时仍能运行，但该样本不参加准确性指标。

真实数据的 role 如果不同，应先适配；未知角色会明确报错，避免静默丢失记录。输入数据或分类失败会终止本次运行；模型调用失败则记录后继续。

## 模拟行为的假设

合成工具输出使用 `Fact answer: ...`，显式分析使用 `Suggested answer: ...`。模拟检查者优先跟随可见的建议，没有建议时比较事实，没有事实时默认接受。这个规则故意展示误导、误杀、缺少证据等不同路径。

这些行为由代码预先指定，不能用模拟指标支持任何论文结论。合成 marker 也不是建议用于真实模型的提示格式。接入真实数据后，必须替换 mock_verify。

预算用空白分词数，input_words_proxy 也是粗略长度；不是 Qwen tokenizer 的 token。模拟耗时是本机函数执行耗时，不是模型延迟。没有虚构真实 token 数、金额或推理成本。正式实验需要使用固定 tokenizer，并记录选择器和检查者的真实 usage、延迟及成本。

当前不训练模型、不做强化学习、不自动下载 benchmark。它是一套用于队友对接的可运行框架。正式实验还需固定模型版本、prompt、解码设置、输出预算、数据划分，保证删除内容不通过旧会话或缓存泄漏，并加入正式统计分析。
