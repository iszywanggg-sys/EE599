import unittest
from pipeline import build_request, classify, make_demo, select_evidence, summarize


class PipelineTests(unittest.TestCase):
    def test_condition_isolation_and_no_label_leak(self):
        sample = make_demo()[0]
        sample['reference_answer'] = 'SECRET_REFERENCE'
        blocks = classify(sample['trajectory'])
        for condition in ('full', 'qa_only', 'no_reasoning', 'selected_evidence'):
            request = build_request(sample, blocks, condition, [])
            self.assertNotIn('label_correct', request)
            self.assertNotIn('SECRET_REFERENCE', str(request))
            if condition != 'full':
                self.assertTrue(all(b['kind'] == 'E' for b in request['context']))
        self.assertEqual(build_request(sample, blocks, 'qa_only', [])['context'], [])

    def test_selection_budget_order_and_reproducibility(self):
        sample = make_demo()[0]
        blocks = classify(sample['trajectory'])
        for method in ('jev_mock', 'random', 'recency', 'relevance'):
            selected = select_evidence(blocks, sample['question'], sample['candidate_answer'], 12, method, 42)
            self.assertLessEqual(sum(len(b['text'].split()) for b in selected), 12)
            self.assertEqual(selected, select_evidence(blocks, sample['question'], sample['candidate_answer'], 12, method, 42))
            self.assertTrue(all(b['kind'] == 'E' for b in selected))
        self.assertEqual(select_evidence(blocks, '', '', 0, 'random', 42), [])

    def test_metric_denominators_and_failures(self):
        rows = []
        for label, verdict, status in [(False, 'incorrect', 'ok'), (False, 'correct', 'ok'), (True, 'incorrect', 'ok'), (True, None, 'error')]:
            rows.append(dict(condition='full', label_correct=label, verdict=verdict, status=status, input_words_proxy=5, verification_ms=1, classification_ms=1, selection_ms=0))
        result = summarize(rows)[0]
        self.assertEqual(result['error_detection_recall'], .5)
        self.assertEqual(result['false_rejection_rate'], 1)
        self.assertEqual(result['balanced_accuracy'], .25)
        self.assertEqual(result['failed'], 1)
        self.assertIsNone(summarize([])[0]['balanced_accuracy'])


if __name__ == '__main__':
    unittest.main()
