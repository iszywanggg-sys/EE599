#!/usr/bin/env python3
"""Offline EE599 integration demo; mock outputs are NOT research results."""
import argparse
import csv
import hashlib
import json
import random
import re
import time
from pathlib import Path

CONDITIONS = ('full', 'qa_only', 'no_reasoning', 'selected_evidence')


def words(text):
    return re.findall(r'\w+', text.lower())


def classify(trajectory):
    """Kai adapter: replace role-based mock with real E/R classification.

    Retains order and metadata. Unknown roles fail rather than disappear.
    """
    result = []
    for block in trajectory:
        if block['role'] not in ('tool', 'assistant'):
            raise ValueError('Unknown trajectory role: ' + block['role'])
        result.append({**block, 'kind': 'E' if block['role'] == 'tool' else 'R'})
    return result


def select_evidence(blocks, question, answer, budget, method, seed):
    """Whole-block selection under whitespace-word budget, NOT model tokens.

    jev_mock is lexical overlap only; it is not an implementation of Jev.
    Returns selected blocks in original order, including contradictory evidence.
    """
    candidates = [(i, b) for i, b in enumerate(blocks) if b['kind'] == 'E']
    query = set(words(question + ' ' + answer))
    if method == 'random':
        random.Random(seed).shuffle(candidates)
    elif method == 'recency':
        candidates.reverse()
    else:
        candidates.sort(key=lambda x: -len(query & set(words(x[1]['text']))))
    chosen, used = [], 0
    for i, block in candidates:
        size = len(block['text'].split())
        if used + size <= budget:
            chosen.append((i, block))
            used += size
    return [b for _, b in sorted(chosen)]


def build_request(sample, blocks, condition, selected):
    """Explicit allowlist: labels/reference answers never enter model input."""
    if condition == 'full':
        context = blocks
    elif condition == 'qa_only':
        context = []
    elif condition == 'no_reasoning':
        context = [b for b in blocks if b['kind'] == 'E']
    elif condition == 'selected_evidence':
        context = selected
    else:
        raise ValueError(condition)
    return {
        'instruction': 'Check the candidate answer using available evidence. Return verdict correct or incorrect and a brief reason.',
        'question': sample['question'],
        'candidate_answer': sample['candidate_answer'],
        'context': context,
    }


def mock_verify(request):
    """Deterministic protocol simulator, not an LLM or validity judge.

    Tool blocks use a deliberately simple 'Fact answer: ...' convention.
    Reasoning can contain 'Suggested answer: ...' to simulate anchoring.
    With no recognized evidence, deliberately defaults to accepting answers.
    This behavior is programmed; differences between conditions prove nothing.
    """
    facts, suggestions = [], []
    for block in request['context']:
        prefix = 'Fact answer: ' if block['kind'] == 'E' else 'Suggested answer: '
        if block['text'].startswith(prefix):
            (facts if block['kind'] == 'E' else suggestions).append(block['text'][len(prefix):].strip())
    if suggestions:
        inferred, reason = suggestions[-1], 'MOCK: followed visible reasoning suggestion.'
    elif facts:
        inferred, reason = facts[-1], 'MOCK: compared with visible fact block.'
    else:
        inferred, reason = request['candidate_answer'], 'MOCK: no recognized fact; default acceptance.'
    verdict = 'correct' if inferred.casefold() == request['candidate_answer'].strip().casefold() else 'incorrect'
    return {'verdict': verdict, 'reason': reason}


def make_demo():
    """Synthetic facts avoid reliance on external knowledge."""
    data = []
    for i in range(12):
        entity = 'Unit' + str(i)
        fact = entity + ' Blue'
        wrong = entity + ' Red'
        candidate = fact if i % 2 == 0 else wrong
        # Some suggestions are correct, some misleading, including false rejection.
        suggestion = wrong if i % 3 == 0 else candidate
        data.append({
            'id': 'demo-%02d' % i,
            'question': 'What is the registered color of ' + entity + '? Answer with unit and color.',
            'candidate_answer': candidate,
            'trajectory': [
                {'id': 'e1', 'role': 'tool', 'source': 'synthetic_registry', 'text': 'Fact answer: ' + fact},
                {'id': 'r1', 'role': 'assistant', 'text': 'Suggested answer: ' + suggestion},
                {'id': 'e2', 'role': 'tool', 'source': 'synthetic_weather', 'text': 'Weather observation: clear sky and light wind today.'},
            ],
            'label_correct': i % 2 == 0,
        })
    return data


def summarize(rows):
    summaries = []
    for condition in CONDITIONS:
        group = [r for r in rows if r['condition'] == condition]
        ok = [r for r in group if r['status'] == 'ok']
        labelled = [r for r in ok if type(r['label_correct']) is bool]
        bad = [r for r in labelled if not r['label_correct']]
        good = [r for r in labelled if r['label_correct']]
        recall = sum(r['verdict'] == 'incorrect' for r in bad) / len(bad) if bad else None
        frr = sum(r['verdict'] == 'incorrect' for r in good) / len(good) if good else None
        summaries.append({
            'condition': condition, 'attempted': len(group), 'succeeded': len(ok),
            'failed': len(group) - len(ok), 'labelled': len(labelled),
            'error_detection_recall': recall, 'false_rejection_rate': frr,
            'balanced_accuracy': (recall + 1 - frr) / 2 if recall is not None and frr is not None else None,
            'mean_input_words_proxy': sum(r['input_words_proxy'] for r in ok) / len(ok) if ok else None,
            'mean_verification_ms': sum(r['verification_ms'] for r in ok) / len(ok) if ok else None,
            'mean_classification_ms': sum(r['classification_ms'] for r in group) / len(group) if group else None,
            'mean_selection_ms': sum(r['selection_ms'] for r in group) / len(group) if group else None,
        })
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, help='JSONL; default: generate 12 synthetic examples')
    parser.add_argument('--output', type=Path, default=Path('outputs/demo'))
    parser.add_argument('--budget', type=int, default=12, help='Evidence whitespace-word budget (not tokens)')
    parser.add_argument('--selector', choices=['jev_mock', 'relevance', 'random', 'recency'], default='jev_mock')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    if args.budget < 0:
        parser.error('--budget must be nonnegative')
    samples = [json.loads(line) for line in args.input.read_text(encoding='utf-8').splitlines() if line.strip()] if args.input else make_demo()
    ids = [s['id'] for s in samples]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate sample IDs')
    for sample in samples:
        for key in ('question', 'candidate_answer'):
            if not isinstance(sample[key], str):
                raise ValueError(key + ' must be a string')
        if 'label_correct' in sample and type(sample['label_correct']) is not bool:
            raise ValueError('label_correct must be boolean or omitted')
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'samples.jsonl').write_text(''.join(json.dumps(s, ensure_ascii=False) + '\n' for s in samples), encoding='utf-8')
    rows = []
    with (args.output / 'results.jsonl').open('w', encoding='utf-8') as output:
        for sample in samples:
            start = time.perf_counter()
            blocks = classify(sample['trajectory'])
            classification_ms = (time.perf_counter() - start) * 1000
            start = time.perf_counter()
            selected = select_evidence(blocks, sample['question'], sample['candidate_answer'], args.budget, args.selector, args.seed)
            selection_ms = (time.perf_counter() - start) * 1000
            for condition in CONDITIONS:
                request = build_request(sample, blocks, condition, selected)
                encoded = json.dumps(request, ensure_ascii=False, sort_keys=True)
                row = {'sample_id': sample['id'], 'condition': condition, 'mode': 'MOCK',
                       'model': 'offline-protocol-simulator-v1', 'selector': args.selector,
                       'label_correct': sample.get('label_correct'), 'request': request,
                       'request_sha256': hashlib.sha256(encoded.encode()).hexdigest(),
                       'input_words_proxy': len(encoded.split()),
                       'classification_ms': classification_ms,
                       'selection_ms': selection_ms if condition == 'selected_evidence' else 0,
                       'verdict': None, 'reason': None, 'error': None}
                start = time.perf_counter()
                try:
                    response = mock_verify(request)  # Magnus adapter: replace this call.
                    if response['verdict'] not in ('correct', 'incorrect'):
                        raise ValueError('Invalid verifier verdict')
                    row.update(response, status='ok')
                except Exception as exc:
                    row.update(status='error', error=str(exc))
                row['verification_ms'] = (time.perf_counter() - start) * 1000
                rows.append(row)
                output.write(json.dumps(row, ensure_ascii=False) + '\n')
                output.flush()
    summary = summarize(rows)
    with (args.output / 'summary.csv').open('w', newline='', encoding='utf-8-sig') as output:
        writer = csv.DictWriter(output, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    manifest = {'mode': 'MOCK_ONLY_NOT_RESEARCH_RESULTS', 'seed': args.seed,
                'selector': args.selector, 'evidence_budget_words': args.budget,
                'samples': len(samples), 'conditions': list(CONDITIONS),
                'input_sha256': hashlib.sha256(json.dumps(samples, sort_keys=True).encode()).hexdigest(),
                'note': 'Word counts are proxies, timings are local simulator timings; no actual token usage or inference cost is measured.'}
    (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('MOCK DEMO ONLY: %d samples, %d checks. Results: %s' % (len(samples), len(rows), args.output.resolve()))
    for item in summary:
        print(item['condition'], 'balanced_accuracy=', item['balanced_accuracy'], 'failed=', item['failed'])


if __name__ == '__main__':
    main()
